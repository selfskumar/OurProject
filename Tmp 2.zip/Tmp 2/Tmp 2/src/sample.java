
import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import apiutils.*;
import org.json.*;

import FileProcessingUtils.ScripMasterUtils;

import javax.net.ssl.HttpsURLConnection;
public class sample {
public static void main(String args[]) throws MalformedURLException {
	try {
//		System.out.println("-----------------------Calling login() method----------------------");
//		LoginUtils.Login();
//
//		System.out.println("-----------------------Calling getPositions() method---------------------");
//		PositionUtils.getPositions();
//
////		System.out.println("------------------------Calling getOrderReq() method------------------------");
////		OrderRequestUtils.getOrderReq();
//
//		System.out.println("------------------------Calling getOrderStatus() method------------------------");
//		OrderStatusUtils.getOrderStatus();
//		
//		System.out.println("------------------------Calling getTradeInfo() method------------------------");
//		TradeInfoUtils.getTradeInfo();
//		
//		System.out.println("------------------------Calling getOrderBook() method------------------------");
//		OrderBookUtils.getOrderBook();
//
//		System.out.println("------------------------Calling getHoldings() method------------------------");
//		HoldingsUtils.getHoldings();
//		
//		System.out.println("------------------------Calling getMargin() method------------------------");
//		MarginUtils.getMargin();
		ScripMasterUtils.updateScripCodesFromFile("C:\\Users\\Babu\\Downloads\\scripmaster11\\Scripmaster11\\contract.txt");
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
}
