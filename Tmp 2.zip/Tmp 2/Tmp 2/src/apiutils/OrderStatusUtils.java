package apiutils;

import org.apache.http.HttpResponse;
import org.json.JSONException;
import org.json.JSONObject;

import baseutils.BaseUtils;

public class OrderStatusUtils {
	
	static JSONObject getHeader() throws JSONException {
		JSONObject head = BaseUtils.getHeadersJson();
		head.put("requestCode", "5POrdStatus");
		return head;
	}

	static JSONObject getBody(String exch, String exchType, String scripCode, String[] remoteOrderIdList) throws JSONException {
		JSONObject body = BaseUtils.getBodyJson();
		body.put("OrdStatusReqList", getOrderIdJsonList(exch, exchType, scripCode, remoteOrderIdList));
		return body;
	}
	
	static JSONObject getOrderListJSON(String exch, String exchType, String scripCode, String remoteOrderId) throws JSONException {
		JSONObject body = new JSONObject();
		body.put("Exch", exch);
		body.put("ExchType", exchType);
		body.put("ScripCode", scripCode);
		body.put("RemoteOrderID", remoteOrderId);
		return body;
	}
	
	static JSONObject[] getOrderIdJsonList(String exch, String exchType, String scripCode, String[] remoteOrderIdList) throws JSONException {
		JSONObject[] list = new JSONObject[remoteOrderIdList.length];
		for(int i=0; i< remoteOrderIdList.length; i++) {
			list[i] = getOrderListJSON(exch, exchType, scripCode, remoteOrderIdList[i]);
		}
		return list;
		
	}
	
	public static JSONObject getInputParameters(String exch, String exchType, String scripCode, String[] remoteOrderIdList) throws JSONException {
		JSONObject inputParameters = new JSONObject();
		inputParameters.put("head", getHeader());
		inputParameters.put("body", getBody(exch, exchType, scripCode, remoteOrderIdList));
		System.out.println(inputParameters.toString());
		return inputParameters;
	}
	
	public static void getOrderStatus() throws JSONException {
		String exch= "N";
		String exchType = "D";
		String scripCode = "54172";
		String[] remoteOrderIdList = {"90980925","90980441"};
		JSONObject inputParameters = getInputParameters(exch, exchType, scripCode, remoteOrderIdList);
		HttpResponse response = (HttpResponse) BaseUtils.executePost("OrderStatus", inputParameters);		
		try {
			BaseUtils.printResponse(response);
		}catch(Exception e) {
			
		}
	}


}
