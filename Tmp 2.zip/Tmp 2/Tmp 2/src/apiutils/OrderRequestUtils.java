package apiutils;

import org.apache.http.HttpResponse;
import org.json.JSONException;
import org.json.JSONObject;

import baseutils.BaseUtils;

public class OrderRequestUtils {

	static JSONObject getHeader() throws JSONException {
		JSONObject head = BaseUtils.getHeadersJson();
		head.put("requestCode", "5POrdReq");
		return head;
	}
	
	static JSONObject getBody() throws JSONException {
		JSONObject body = BaseUtils.getBodyJson();
		body.put("OrderFor", "P");
		body.put("Exchange", "N");
		body.put("ExchangeType", "D");
		body.put("Price", 0);
		body.put("OrderID", 0);
		body.put("OrderType", "SELL");
		body.put("Qty", 20);
		body.put("OrderDateTime", "/Date(1556104184000)/");
		body.put("ScripCode", 51472);
		body.put("AtMarket", true);
		body.put("RemoteOrderID", "57129776201804050344475");
		body.put("ExchOrderID", 0);
		body.put("DisQty", 0);
		body.put("IsStopLossOrder", false);
		body.put("StopLossPrice", 0);
		body.put("IsVTD", false);
		body.put("IOCOrder", false);
		body.put("IsIntraday", false);
		body.put("PublicIP", "27.5.72.153");
		body.put("AHPlaced", "N");
		body.put("ValidTillDate", "/Date(1556104184000)/");
		body.put("iOrderValidity", 0);
		body.put("TradedQty", 0);
		body.put("OrderRequesterCode", "56886446");
		body.put("AppSource", 713);

		return body;
	}
	
	public static JSONObject getInputParameters() throws JSONException {
		JSONObject inputParameters = new JSONObject();
		inputParameters.put("head", getHeader());
		inputParameters.put("body", getBody());
		System.out.println(inputParameters.toString());
		return inputParameters;
	}

	public static void getOrderReq() throws JSONException {
		JSONObject inputParameters = getInputParameters();
		HttpResponse response = (HttpResponse) BaseUtils.executePost("V1/OrderRequest", inputParameters);		
		try {
			BaseUtils.printResponse(response);
		}catch(Exception e) {
			
		}
	}


}
