package apiutils;

import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.json.JSONException;
import org.json.JSONObject;

import baseutils.BaseUtils;

public class LoginUtils {
	static JSONObject getHeader() throws JSONException {
		JSONObject head = BaseUtils.getHeadersJson();
		head.put("requestCode", "5PLoginV2");
		return head;
	}

	static JSONObject getBody() throws JSONException {
		JSONObject body = new JSONObject();
		body.put("Email_id", "nhskCTFAckhVg+vLO1xgGivIeLASrxVV+/wNDMyQc2I=");
		body.put("Password", "RuLYv3Xhjn+hzenlmuL/EQ==");
		body.put("LocalIP", "192.168.1.5");
		body.put("PublicIP", "27.5.72.153");
		body.put("HDSerailNumber", "C02XKKJVJG5H");
		body.put("MACAddress", "f0:18:98:6a:50:e5");
		body.put("MachineID", "038755");
		body.put("VersionNo", "1.7");
		body.put("RequestNo", "1");
		body.put("My2PIN", "e+ZfHwxr1B6mTiyrqpOE8g==");
		body.put("ConnectionType", "1");
		return body;
	}

	public static JSONObject getInputParameters() throws JSONException {
		JSONObject inputParameters = new JSONObject();
		inputParameters.put("head", getHeader());
		inputParameters.put("body", getBody());
		System.out.println(inputParameters.toString());
		return inputParameters;
	}
	
	public static void Login() throws JSONException {
		
		JSONObject inputParameters = getInputParameters();
		HttpResponse response = (HttpResponse) BaseUtils.executePost("V2/LoginRequestMobileNewbyEmail", inputParameters);		
		try {
			BaseUtils.printResponse(response);
			Header setCookie = response.getFirstHeader("Set-Cookie");
			String cookieKeyValue = setCookie.getValue().split(";")[0];
			BaseUtils.setCookie(cookieKeyValue.split("=")[1]);
		}catch(Exception e) {
			
		}
	}


}
