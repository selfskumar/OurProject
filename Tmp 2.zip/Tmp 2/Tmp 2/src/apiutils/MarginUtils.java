package apiutils;

import org.apache.http.HttpResponse;
import org.json.JSONException;
import org.json.JSONObject;

import baseutils.BaseUtils;

public class MarginUtils {
	static JSONObject getHeader() throws JSONException {
		JSONObject head = BaseUtils.getHeadersJson();
		head.put("requestCode", "5PMarginV3");
		return head;
	}

	static JSONObject getInputParameters() throws JSONException {
		JSONObject inputParameters = new JSONObject();
		inputParameters.put("head", getHeader());
		inputParameters.put("body", BaseUtils.getBodyJson());
		System.out.println(inputParameters.toString());
		return inputParameters;
	}
	
	public static void getMargin() throws JSONException {
		JSONObject inputParameters = getInputParameters();
		HttpResponse response = (HttpResponse) BaseUtils.executePost("V3/Margin", inputParameters);		
		try {
			BaseUtils.printResponse(response);
		}catch(Exception e) {
			
		}
	}


}
