package apiutils;

import org.apache.http.HttpResponse;
import org.json.JSONException;
import org.json.JSONObject;

import baseutils.BaseUtils;

public class PositionUtils {

	static JSONObject getHeader() throws JSONException {
		JSONObject head = BaseUtils.getHeadersJson();
		head.put("requestCode", "5PNPNWV1");
		return head;
	}

	public static JSONObject getInputParameters() throws JSONException {
		JSONObject inputParameters = new JSONObject();
		inputParameters.put("head", getHeader());
		inputParameters.put("body", BaseUtils.getBodyJson());
		System.out.println(inputParameters.toString());
		return inputParameters;
	}
	
	public static void getPositions() throws JSONException {
		JSONObject inputParameters = getInputParameters();
		HttpResponse response = (HttpResponse) BaseUtils.executePost("V1/NetPositionNetWise", inputParameters);		
		try {
			BaseUtils.printResponse(response);
		}catch(Exception e) {
			
		}
	}

}
