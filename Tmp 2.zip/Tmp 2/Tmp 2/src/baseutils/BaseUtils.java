package baseutils;

import org.apache.http.HttpResponse;
import org.apache.http.HttpResponseFactory;
import org.apache.http.HttpStatus;
import org.apache.http.HttpVersion;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.DefaultHttpResponseFactory;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.cookie.BasicClientCookie;
import org.apache.http.message.BasicStatusLine;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

public class BaseUtils {
	private static String COOKIE = "";
	public static JSONObject getHeadersJson() throws JSONException {
		JSONObject head = new JSONObject();
		head.put("appName", "5PATM");
		head.put("appVer", "1.0");
		head.put("key", "gB7a1XaNKP4gcNsiAQ3VRcgpLC4YWOkL");
		head.put("osName", "WEB");
		head.put("userId", "Ibh14eHakb6");
		head.put("password", "i6r46sCOnsT");
		return head;
	}

	public static JSONObject getBodyJson() throws JSONException{
		JSONObject body = new JSONObject();
		body.put("ClientCode", "56886446");
		return body;
	}
	
	public static void printResponse(HttpResponse response) {
		try {
			String responseJSON = EntityUtils.toString(response.getEntity(), "UTF-8");
			System.out.println(response);
			System.out.println(responseJSON);
		}catch(Exception e) {
			
		}
	}
	
	 public static HttpResponse executePost(String method, JSONObject inputParameters) {
		String url = "https://Openapi.5paisa.com/VendorsAPI/Service1.svc" + "/" + method;
		DefaultHttpClient httpClient = new DefaultHttpClient();
		HttpPost postRequest = new HttpPost(url);
		postRequest.addHeader("Content-Type", "application/json");
		if(!method.equalsIgnoreCase("V2/LoginRequestMobileNewbyEmail")) {
		    BasicCookieStore cookieStore = new BasicCookieStore();
		    BasicClientCookie cookie = new BasicClientCookie("5paisacookie", COOKIE);
		    cookie.setDomain(".5paisa.com");
		    cookie.setPath("/");
		    cookieStore.addCookie(cookie);
		    httpClient.setCookieStore(cookieStore);
		}
		HttpResponseFactory factory = new DefaultHttpResponseFactory();
		HttpResponse response = factory.newHttpResponse(new BasicStatusLine(HttpVersion.HTTP_1_1, HttpStatus.SC_OK, null), null);
		try {
			StringEntity params =new StringEntity(inputParameters.toString());
			postRequest.setEntity(params);
			response = httpClient.execute(postRequest);
			return response;
		}catch(Exception e) {
			
		}
		return response;
	}
	 
	 public static void setCookie(String cookie) {
		 COOKIE = cookie;
		 
	 }

}
