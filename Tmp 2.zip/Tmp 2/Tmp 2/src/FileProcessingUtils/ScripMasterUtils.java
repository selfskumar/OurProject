package FileProcessingUtils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ScripMasterUtils {
	public static void updateScripCodesFromFile(String fileName) throws IOException {
		File f = new File(fileName);
		 BufferedReader b = new BufferedReader(new FileReader(f));
		 String readLine = ""; 
		 int i =0;
		 while ((readLine = b.readLine()) != null && i <11) {
			 if(i==0) { i++; continue;}
             String[] list = readLine.split("\\|");
             String scripCode = list[0];
             String type = list[2];
             String scrip = list[3];
             String expiryDate = Long.toString(Long.parseLong(list[6]) + 315532836); //           add   315532836 . the timestamp for 10 years.
             String strikePrice = list[7];
             String optionType = list[8];
             printTimeStamp(expiryDate);
             i++;
         }
	}
	public static void printTimeStamp(String str) {
		System.out.println(str);
		Timestamp ts=new Timestamp(Long.parseLong(str));
		Date date=new Date(ts.getTime());  
		System.out.println(date);

	}
}
